import { Link, useLocation } from "wouter";
import { useStore } from "@/lib/store";
import { 
  Activity, 
  LayoutDashboard, 
  Users, 
  MessageSquare, 
  FileText, 
  LogOut,
  Stethoscope,
  Menu
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";
import { cn } from "@/lib/utils";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const { userRole, setUserRole } = useStore();
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  const handleLogout = () => {
    setUserRole(null);
    setLocation("/");
  };

  const NavItem = ({ href, icon: Icon, label }: { href: string; icon: any; label: string }) => {
    const isActive = location === href;
    return (
      <Link href={href}>
        <div className={cn(
          "flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors cursor-pointer",
          isActive 
            ? "bg-primary text-primary-foreground shadow-sm" 
            : "text-muted-foreground hover:bg-secondary hover:text-foreground"
        )}>
          <Icon className="h-5 w-5" />
          <span>{label}</span>
        </div>
      </Link>
    );
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-card border-r">
      <div className="p-6 border-b flex items-center gap-2">
        <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
          <Activity className="h-5 w-5 text-white" />
        </div>
        <span className="font-heading font-bold text-xl text-primary">VitalSix</span>
      </div>

      <div className="flex-1 py-6 px-4 space-y-1">
        {userRole === 'asha' && (
          <>
            <div className="px-4 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              ASHA Workspace
            </div>
            <NavItem href="/dashboard/asha" icon={LayoutDashboard} label="Dashboard" />
            <NavItem href="/dashboard/asha/patients" icon={Users} label="My Patients" />
            <NavItem href="/dashboard/asha/consultations" icon={MessageSquare} label="Consultations" />
          </>
        )}

        {userRole === 'doctor' && (
          <>
            <div className="px-4 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              Doctor Workspace
            </div>
            <NavItem href="/dashboard/doctor" icon={Stethoscope} label="Consultation Requests" />
            <NavItem href="/dashboard/doctor/patients" icon={Users} label="Patient Records" />
            <NavItem href="/dashboard/doctor/history" icon={FileText} label="History" />
          </>
        )}
      </div>

      <div className="p-4 border-t">
        <Button variant="ghost" className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10" onClick={handleLogout}>
          <LogOut className="mr-2 h-4 w-4" />
          Logout
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-secondary/30 flex">
      {/* Desktop Sidebar */}
      <div className="hidden md:block w-64 fixed inset-y-0 z-50">
        <SidebarContent />
      </div>

      {/* Mobile Sidebar */}
      <Sheet open={isMobileOpen} onOpenChange={setIsMobileOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="md:hidden fixed top-4 left-4 z-50">
            <Menu className="h-6 w-6" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0 w-64">
          <SidebarContent />
        </SheetContent>
      </Sheet>

      {/* Main Content */}
      <main className="flex-1 md:ml-64 p-4 md:p-8 pt-16 md:pt-8 min-h-screen">
        <div className="max-w-5xl mx-auto animate-in fade-in duration-500">
          {children}
        </div>
      </main>
    </div>
  );
}
