import { create } from 'zustand';

export type Role = 'asha' | 'doctor' | null;

export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  symptoms: string[];
  history: string;
  lastVisit: string;
  status: 'Stable' | 'Critical' | 'Under Observation';
}

export interface Consultation {
  id: string;
  patientId: string;
  doctorId: string | null;
  status: 'pending' | 'active' | 'completed' | 'rejected';
  symptoms: string[];
  aiRecommendation: string;
  messages: { sender: 'asha' | 'doctor'; text: string; timestamp: string }[];
  notes: string;
  timestamp: string;
}

interface AppState {
  userRole: Role;
  setUserRole: (role: Role) => void;
  patients: Patient[];
  consultations: Consultation[];
  addPatient: (patient: Omit<Patient, 'id'>) => void;
  requestConsultation: (patientId: string, symptoms: string[]) => void;
  updateConsultationStatus: (id: string, status: Consultation['status']) => void;
  addMessage: (consultationId: string, text: string, sender: 'asha' | 'doctor') => void;
}

// Mock Data
const MOCK_PATIENTS: Patient[] = [
  { id: '1', name: 'Ramesh Kumar', age: 45, gender: 'Male', symptoms: ['High Fever', 'Cough'], history: 'Hypertension', lastVisit: '2023-10-15', status: 'Under Observation' },
  { id: '2', name: 'Sita Devi', age: 28, gender: 'Female', symptoms: ['Fatigue', 'Nausea'], history: 'Pregnancy - 2nd Trimester', lastVisit: '2023-11-01', status: 'Stable' },
  { id: '3', name: 'Aarav Singh', age: 8, gender: 'Male', symptoms: ['Skin Rash', 'Itching'], history: 'None', lastVisit: '2023-11-05', status: 'Stable' },
];

const MOCK_CONSULTATIONS: Consultation[] = [
  { 
    id: 'c1', 
    patientId: '1', 
    doctorId: null, 
    status: 'pending', 
    symptoms: ['High Fever', 'Cough'], 
    aiRecommendation: 'General Physician', 
    messages: [], 
    notes: '', 
    timestamp: '2023-11-10T10:00:00Z' 
  },
  { 
    id: 'c2', 
    patientId: '2', 
    doctorId: 'd1', 
    status: 'active', 
    symptoms: ['Fatigue', 'Nausea'], 
    aiRecommendation: 'Gynecologist', 
    messages: [
      { sender: 'asha', text: 'Patient reports persistent nausea for 3 days.', timestamp: '2023-11-11T09:00:00Z' },
      { sender: 'doctor', text: 'Any signs of dehydration?', timestamp: '2023-11-11T09:05:00Z' }
    ], 
    notes: '', 
    timestamp: '2023-11-11T09:00:00Z' 
  },
];

export const useStore = create<AppState>((set) => ({
  userRole: null,
  setUserRole: (role) => set({ userRole: role }),
  patients: MOCK_PATIENTS,
  consultations: MOCK_CONSULTATIONS,
  
  addPatient: (patient) => set((state) => ({
    patients: [...state.patients, { ...patient, id: Math.random().toString(36).substr(2, 9) }]
  })),

  requestConsultation: (patientId, symptoms) => set((state) => {
    // Simple AI Mock Logic
    let aiRecommendation = 'General Physician';
    const s = symptoms.join(' ').toLowerCase();
    if (s.includes('pregnant') || s.includes('nausea') || s.includes('stomach')) aiRecommendation = 'Gynecologist';
    if (s.includes('child') || s.includes('baby') || s.includes('rash')) aiRecommendation = 'Pediatrician';
    if (s.includes('heart') || s.includes('chest')) aiRecommendation = 'Cardiologist';

    return {
      consultations: [...state.consultations, {
        id: Math.random().toString(36).substr(2, 9),
        patientId,
        doctorId: null,
        status: 'pending',
        symptoms,
        aiRecommendation,
        messages: [],
        notes: '',
        timestamp: new Date().toISOString()
      }]
    };
  }),

  updateConsultationStatus: (id, status) => set((state) => ({
    consultations: state.consultations.map(c => c.id === id ? { ...c, status } : c)
  })),

  addMessage: (consultationId, text, sender) => set((state) => ({
    consultations: state.consultations.map(c => c.id === consultationId ? {
      ...c,
      messages: [...c.messages, { text, sender, timestamp: new Date().toISOString() }]
    } : c)
  })),
}));
