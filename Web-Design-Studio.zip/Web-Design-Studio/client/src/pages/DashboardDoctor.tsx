import { useStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Check, X, MessageSquare, Clock, User } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import ashaImg from "@/assets/asha-avatar.png";

export default function DashboardDoctor() {
  const { consultations, patients, updateConsultationStatus, addMessage } = useStore();
  const { toast } = useToast();
  const [activeConsultation, setActiveConsultation] = useState<string | null>(null);
  const [messageText, setMessageText] = useState("");

  const pendingConsultations = consultations.filter(c => c.status === 'pending');
  const activeConsultations = consultations.filter(c => c.status === 'active');

  const getPatient = (id: string) => patients.find(p => p.id === id);

  const handleAccept = (id: string) => {
    updateConsultationStatus(id, 'active');
    toast({ title: "Consultation Accepted", description: "You can now chat with the ASHA worker." });
  };

  const handleSendMessage = () => {
    if (activeConsultation && messageText) {
      addMessage(activeConsultation, messageText, 'doctor');
      setMessageText("");
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-heading font-bold text-foreground">Doctor's Portal</h1>
        <p className="text-muted-foreground">Dr. Sharma (General Physician)</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        
        {/* Left Column: Requests */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-accent-foreground" />
                Incoming Requests
              </CardTitle>
            </CardHeader>
            <CardContent>
              {pendingConsultations.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">No pending requests.</div>
              ) : (
                <div className="space-y-4">
                  {pendingConsultations.map(consult => {
                    const patient = getPatient(consult.patientId);
                    if (!patient) return null;
                    return (
                      <div key={consult.id} className="p-4 border rounded-xl bg-card shadow-sm">
                        <div className="flex justify-between items-start mb-4">
                          <div className="flex gap-4">
                            <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold text-lg">
                              {patient.name.charAt(0)}
                            </div>
                            <div>
                              <h3 className="font-bold text-lg">{patient.name}</h3>
                              <p className="text-sm text-muted-foreground">{patient.age} years • {patient.gender}</p>
                            </div>
                          </div>
                          <Badge variant="secondary" className="bg-purple-100 text-purple-700 hover:bg-purple-200">
                            AI Recommendation: {consult.aiRecommendation}
                          </Badge>
                        </div>
                        
                        <div className="bg-muted/50 p-3 rounded-lg mb-4 text-sm">
                          <span className="font-semibold text-muted-foreground">Symptoms: </span>
                          {consult.symptoms.join(", ")}
                        </div>

                        <div className="flex gap-3">
                          <Button className="flex-1 bg-green-600 hover:bg-green-700" onClick={() => handleAccept(consult.id)}>
                            <Check className="mr-2 h-4 w-4" /> Accept Case
                          </Button>
                          <Button variant="outline" className="flex-1 text-destructive hover:bg-destructive/10">
                            <X className="mr-2 h-4 w-4" /> Decline
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Active Consultations</CardTitle>
            </CardHeader>
            <CardContent>
              {activeConsultations.map(consult => {
                 const patient = getPatient(consult.patientId);
                 if (!patient) return null;
                 return (
                   <div key={consult.id} className="flex items-center justify-between p-4 border-b last:border-0">
                     <div className="flex items-center gap-3">
                       <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center text-green-700 font-bold">
                         {patient.name.charAt(0)}
                       </div>
                       <div>
                         <div className="font-medium">{patient.name}</div>
                         <div className="text-xs text-muted-foreground">Started 10 mins ago</div>
                       </div>
                     </div>
                     <Dialog>
                       <DialogTrigger asChild>
                         <Button size="sm" onClick={() => setActiveConsultation(consult.id)}>
                           <MessageSquare className="mr-2 h-4 w-4" /> Open Chat
                         </Button>
                       </DialogTrigger>
                       <DialogContent className="max-w-2xl h-[600px] flex flex-col">
                         <DialogHeader>
                           <DialogTitle>Consultation: {patient.name}</DialogTitle>
                           <CardDescription>Connected with ASHA Worker</CardDescription>
                         </DialogHeader>
                         
                         <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-secondary/20 rounded-lg my-4">
                            {consult.messages.length === 0 && (
                              <div className="text-center text-muted-foreground text-sm italic py-4">No messages yet. Start the conversation.</div>
                            )}
                            {consult.messages.map((msg, i) => (
                              <div key={i} className={`flex ${msg.sender === 'doctor' ? 'justify-end' : 'justify-start'}`}>
                                <div className={`max-w-[80%] p-3 rounded-lg ${
                                  msg.sender === 'doctor' 
                                    ? 'bg-primary text-primary-foreground rounded-tr-none' 
                                    : 'bg-white border text-foreground rounded-tl-none'
                                }`}>
                                  <div className="text-xs opacity-70 mb-1 capitalize">{msg.sender}</div>
                                  {msg.text}
                                </div>
                              </div>
                            ))}
                         </div>

                         <div className="flex gap-2">
                           <input 
                              className="flex-1 h-10 rounded-md border border-input px-3 bg-background" 
                              placeholder="Type advice or prescription..."
                              value={messageText}
                              onChange={e => setMessageText(e.target.value)}
                              onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
                           />
                           <Button onClick={handleSendMessage}>Send</Button>
                         </div>
                       </DialogContent>
                     </Dialog>
                   </div>
                 )
              })}
            </CardContent>
          </Card>
        </div>

        {/* Right Column: Profile/Stats */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>My Profile</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col items-center text-center">
              <div className="h-24 w-24 rounded-full bg-muted mb-4 overflow-hidden">
                <img src="https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3" alt="Doctor" className="h-full w-full object-cover" />
              </div>
              <h3 className="font-bold text-lg">Dr. Rajesh Sharma</h3>
              <p className="text-muted-foreground text-sm">General Physician • MBBS, MD</p>
              <div className="mt-4 grid grid-cols-2 gap-4 w-full">
                <div className="p-3 bg-secondary/50 rounded-lg">
                  <div className="text-2xl font-bold text-primary">12</div>
                  <div className="text-xs text-muted-foreground">Patients Today</div>
                </div>
                <div className="p-3 bg-secondary/50 rounded-lg">
                  <div className="text-2xl font-bold text-primary">4.8</div>
                  <div className="text-xs text-muted-foreground">Rating</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

      </div>
    </div>
  );
}
