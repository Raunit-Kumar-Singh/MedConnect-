import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { useStore, Patient, Consultation } from "@/lib/store";
import { 
  Card, CardContent, CardHeader, CardTitle, CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  ArrowLeft, 
  User, 
  Activity, 
  Thermometer, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  Stethoscope,
  MessageSquare,
  Send,
  Loader2
} from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function ConsultationPage() {
  const [match, params] = useRoute("/consult/:patientId");
  const [_, setLocation] = useLocation();
  const { patients, consultations, requestConsultation, userRole, addMessage } = useStore();
  const { toast } = useToast();

  const [symptoms, setSymptoms] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiResult, setAiResult] = useState<{ rec: string; urgency: string; reasoning: string[] } | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);
  const [messageText, setMessageText] = useState("");

  const patient = patients.find(p => p.id === params?.patientId);
  const activeConsultation = consultations.find(c => c.patientId === params?.patientId && (c.status === 'pending' || c.status === 'active'));

  if (!patient) return <div className="p-8 text-center">Patient not found</div>;

  const handleAnalyze = () => {
    setIsAnalyzing(true);
    setAiResult(null);
    setTimeout(() => {
      setIsAnalyzing(false);
      const isPregnant = symptoms.toLowerCase().includes("pregnant");
      setAiResult({
        rec: isPregnant ? "Gynecologist" : "General Physician",
        urgency: symptoms.toLowerCase().includes("severe") || symptoms.toLowerCase().includes("chest") ? "Critical" : "Moderate",
        reasoning: [
          "Symptom duration > 48 hours",
          isPregnant ? "Pregnancy risk factor" : "Fever protocol indicated",
          "Rural triage guidelines applied"
        ]
      });
    }, 2000);
  };

  const handleRequest = () => {
    if (aiResult) {
      requestConsultation(patient.id, symptoms.split(","));
      setShowSuccess(true);
      toast({ title: "Request Sent", description: "Waiting for doctor to connect..." });
    }
  };

  const handleSendMessage = () => {
    if (activeConsultation && messageText.trim()) {
      addMessage(activeConsultation.id, messageText, 'asha');
      setMessageText("");
    }
  };

  if (showSuccess && !activeConsultation) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh] text-center space-y-6 animate-in zoom-in-95 duration-500">
        <div className="h-24 w-24 bg-primary/10 rounded-full flex items-center justify-center">
          <CheckCircle2 className="h-12 w-12 text-primary" />
        </div>
        <div className="space-y-2">
          <h2 className="text-3xl font-heading font-bold">Request Sent Successfully</h2>
          <p className="text-muted-foreground max-w-md mx-auto">Your consultation request has been broadcast to available specialists. You'll be notified once a doctor accepts the case.</p>
        </div>
        <Button size="lg" className="rounded-2xl h-14 px-8" onClick={() => setLocation("/dashboard/asha")}>
          Return to Dashboard
        </Button>
      </div>
    );
  }

  return (
    <div className="grid lg:grid-cols-12 gap-6 pb-20">
      {/* LEFT PANEL - Patient Summary */}
      <div className="lg:col-span-3">
        <div className="sticky top-20 space-y-4">
          <Card className="rounded-3xl border-2 overflow-hidden shadow-sm">
            <CardHeader className="bg-primary/5 pb-4">
              <div className="flex justify-between items-start">
                <div className="h-12 w-12 rounded-xl bg-primary/20 flex items-center justify-center text-primary font-bold">
                  {patient.name.charAt(0)}
                </div>
                <Badge variant={patient.status === 'Critical' ? 'destructive' : 'secondary'} className="rounded-full uppercase text-[10px] tracking-widest font-bold">
                  {patient.status}
                </Badge>
              </div>
              <CardTitle className="mt-4">{patient.name}</CardTitle>
              <CardDescription>{patient.age}y • {patient.gender}</CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground">Temperature</span>
                  <span className="font-bold">98.6°F</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground">BP</span>
                  <span className="font-bold">120/80</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground">Heart Rate</span>
                  <span className="font-bold">72 bpm</span>
                </div>
              </div>
              <Separator />
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Clock className="h-3 w-3" />
                Last visit: {patient.lastVisit}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* CENTER PANEL - Interaction */}
      <div className="lg:col-span-6 space-y-6">
        {!activeConsultation ? (
          <Card className="rounded-3xl border-2">
            <CardHeader>
              <CardTitle>Symptom Assessment</CardTitle>
              <CardDescription>Enter details for AI triage and doctor review</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="font-bold">Detailed Symptoms</Label>
                  <Textarea 
                    placeholder="Describe symptoms, duration, and severity..." 
                    className="min-h-[150px] rounded-2xl border-2 focus:border-primary p-4 text-base"
                    value={symptoms}
                    onChange={e => setSymptoms(e.target.value)}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2 p-3 border-2 rounded-xl">
                    <Checkbox id="child" />
                    <label htmlFor="child" className="text-sm font-medium">Child Patient</label>
                  </div>
                  <div className="flex items-center space-x-2 p-3 border-2 rounded-xl">
                    <Checkbox id="pregnant" />
                    <label htmlFor="pregnant" className="text-sm font-medium">Pregnant</label>
                  </div>
                </div>

                <Button 
                  className="w-full h-14 rounded-2xl text-lg font-bold" 
                  onClick={handleAnalyze}
                  disabled={isAnalyzing || symptoms.length < 5}
                >
                  {isAnalyzing ? <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Analyzing...</> : "Analyze Symptoms"}
                </Button>
              </div>

              {isAnalyzing && (
                <div className="space-y-4 p-6 bg-muted/50 rounded-2xl border-2 border-dashed animate-pulse">
                  <Skeleton className="h-4 w-[100px]" />
                  <Skeleton className="h-10 w-full" />
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-[80%]" />
                  </div>
                </div>
              )}

              {aiResult && !isAnalyzing && (
                <div className="p-6 bg-primary/5 rounded-2xl border-2 border-primary/20 space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-primary font-bold">
                      <Stethoscope className="h-5 w-5" /> AI Triage Result
                    </div>
                    <Badge className={cn(
                      "px-4 py-1 rounded-full",
                      aiResult.urgency === 'Critical' ? 'bg-destructive' : 'bg-primary'
                    )}>
                      {aiResult.urgency} Urgency
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-white rounded-xl border">
                      <div className="text-xs text-muted-foreground uppercase mb-1">Recommended Specialist</div>
                      <div className="font-bold">{aiResult.rec}</div>
                    </div>
                    <div className="p-4 bg-white rounded-xl border">
                      <div className="text-xs text-muted-foreground uppercase mb-1">Triage Score</div>
                      <div className="font-bold text-primary">8.5/10</div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-sm font-bold">Reasoning:</div>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      {aiResult.reasoning.map((r, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <div className="h-1.5 w-1.5 rounded-full bg-primary/50" /> {r}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Button className="w-full h-14 rounded-2xl text-lg font-bold shadow-xl shadow-primary/30" onClick={handleRequest}>
                    Send Consultation Request
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            <Card className="rounded-3xl border-2 h-[600px] flex flex-col overflow-hidden">
              <CardHeader className="border-b bg-card">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center text-white font-bold">
                      {activeConsultation.status === 'active' ? 'D' : '?'}
                    </div>
                    <div>
                      <CardTitle className="text-lg">
                        {activeConsultation.status === 'active' ? 'Dr. Rajesh Sharma' : 'Finding Specialist...'}
                      </CardTitle>
                      <CardDescription>
                        {activeConsultation.status === 'active' ? 'Online • Consulting' : 'Request broadcasted to 5 doctors'}
                      </CardDescription>
                    </div>
                  </div>
                  <Badge variant={activeConsultation.status === 'active' ? 'default' : 'outline'} className="animate-pulse">
                    {activeConsultation.status === 'active' ? 'Connected' : 'Pending'}
                  </Badge>
                </div>
              </CardHeader>

              <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-secondary/20">
                {activeConsultation.status === 'pending' && (
                  <div className="flex flex-col items-center justify-center h-full text-center space-y-4">
                    <div className="h-16 w-16 bg-white rounded-full flex items-center justify-center shadow-sm">
                      <Loader2 className="h-8 w-8 text-primary animate-spin" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-bold text-lg">Waiting for Doctor</h3>
                      <p className="text-sm text-muted-foreground max-w-xs">Connecting you with an available specialist. This usually takes 2-3 minutes.</p>
                    </div>
                  </div>
                )}
                
                {activeConsultation.messages.map((msg, i) => (
                  <div key={i} className={cn("flex", msg.sender === 'asha' ? "justify-end" : "justify-start")}>
                    <div className={cn(
                      "max-w-[80%] p-4 rounded-2xl text-sm shadow-sm",
                      msg.sender === 'asha' 
                        ? "bg-primary text-primary-foreground rounded-tr-none" 
                        : "bg-white border-2 text-foreground rounded-tl-none"
                    )}>
                      {msg.text}
                      <div className="text-[10px] mt-1 opacity-60 text-right">
                        {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {activeConsultation.status === 'active' && (
                <CardHeader className="border-t p-4">
                  <div className="flex gap-2">
                    <Input 
                      placeholder="Type a message..." 
                      className="rounded-xl h-12 border-2"
                      value={messageText}
                      onChange={e => setMessageText(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
                    />
                    <Button size="icon" className="h-12 w-12 rounded-xl" onClick={handleSendMessage}>
                      <Send className="h-5 w-5" />
                    </Button>
                  </div>
                </CardHeader>
              )}
            </Card>
          </div>
        )}
      </div>

      {/* RIGHT PANEL - Status Timeline */}
      <div className="lg:col-span-3">
        <Card className="rounded-3xl border-2">
          <CardHeader>
            <CardTitle className="text-base">Consultation Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {[
                { label: 'Draft', done: true },
                { label: 'Requested', done: !!activeConsultation },
                { label: 'Accepted by Doctor', done: activeConsultation?.status === 'active' },
                { label: 'In Consultation', done: activeConsultation?.status === 'active' },
                { label: 'Completed', done: activeConsultation?.status === 'completed' }
              ].map((step, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className={cn(
                    "h-6 w-6 rounded-full flex items-center justify-center text-xs font-bold",
                    step.done ? "bg-primary text-white" : "bg-muted text-muted-foreground border-2"
                  )}>
                    {step.done ? <CheckCircle2 className="h-4 w-4" /> : i + 1}
                  </div>
                  <span className={cn("text-sm font-medium", step.done ? "text-foreground" : "text-muted-foreground")}>
                    {step.label}
                  </span>
                </div>
              ))}
            </div>
            {activeConsultation && (
              <div className="mt-8 pt-6 border-t">
                <div className="text-xs text-muted-foreground uppercase mb-1">Case ID</div>
                <div className="text-sm font-mono font-bold">#{activeConsultation.id.toUpperCase()}</div>
                <div className="text-[10px] text-muted-foreground mt-2">
                  Created {new Date(activeConsultation.timestamp).toLocaleString()}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Separator() {
  return <div className="h-px w-full bg-border" />;
}
