import { useRoute, useLocation } from "wouter";
import { useStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, User, Calendar, Activity, FileText, Pill } from "lucide-react";
import { Separator } from "@/components/ui/separator";

export default function PatientDetails() {
  const [match, params] = useRoute("/patients/:id");
  const [_, setLocation] = useLocation();
  const { patients, consultations, userRole } = useStore();

  if (!match || !params) return <div>Invalid Route</div>;

  const patient = patients.find(p => p.id === params.id);
  const patientConsultations = consultations.filter(c => c.patientId === params.id);

  if (!patient) return (
    <div className="flex flex-col items-center justify-center h-[50vh] gap-4">
      <h2 className="text-2xl font-bold text-muted-foreground">Patient Not Found</h2>
      <Button variant="outline" onClick={() => setLocation(userRole === 'asha' ? '/dashboard/asha' : '/dashboard/doctor')}>
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
      </Button>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => setLocation(userRole === 'asha' ? '/dashboard/asha' : '/dashboard/doctor')}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-3xl font-heading font-bold">{patient.name}</h1>
          <p className="text-muted-foreground">Patient ID: {patient.id}</p>
        </div>
        <div className="ml-auto">
           <Badge variant={patient.status === 'Critical' ? 'destructive' : 'default'} className="text-lg px-4 py-1">
             {patient.status}
           </Badge>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Left Col: Vitals & Info */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" /> Vitals
              </CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 gap-4">
              <div className="p-4 bg-primary/5 rounded-2xl border border-primary/10">
                <div className="text-xs text-muted-foreground uppercase font-bold tracking-wider mb-1">Temperature</div>
                <div className="text-2xl font-bold text-primary">98.6°F</div>
              </div>
              <div className="p-4 bg-primary/5 rounded-2xl border border-primary/10">
                <div className="text-xs text-muted-foreground uppercase font-bold tracking-wider mb-1">Blood Pressure</div>
                <div className="text-2xl font-bold text-primary">120/80</div>
              </div>
              <div className="p-4 bg-primary/5 rounded-2xl border border-primary/10">
                <div className="text-xs text-muted-foreground uppercase font-bold tracking-wider mb-1">Heart Rate</div>
                <div className="text-2xl font-bold text-primary">72 bpm</div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5 text-primary" /> Basic Info
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between py-2 border-b">
                <span className="text-muted-foreground">Age</span>
                <span className="font-medium">{patient.age} years</span>
              </div>
              <div className="flex justify-between py-2 border-b">
                <span className="text-muted-foreground">Gender</span>
                <span className="font-medium">{patient.gender}</span>
              </div>
              <div className="flex justify-between py-2 border-b">
                <span className="text-muted-foreground">Last Visit</span>
                <span className="font-medium">{patient.lastVisit}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" /> Medical History
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm leading-relaxed">{patient.history || "No significant history recorded."}</p>
            </CardContent>
          </Card>
        </div>

        {/* Right Col: Timeline/Consultations */}
        <div className="md:col-span-2 space-y-6">
          <Card>
             <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" /> Consultation History
              </CardTitle>
             </CardHeader>
             <CardContent>
               <div className="space-y-8 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-slate-300 before:to-transparent">
                  {patientConsultations.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">No consultation history available.</div>
                  ) : (
                    patientConsultations.map((consult) => (
                      <div key={consult.id} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                        <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-slate-300 group-[.is-active]:bg-primary text-slate-500 group-[.is-active]:text-emerald-50 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
                          <Stethoscope className="w-5 h-5" />
                        </div>
                        <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded border border-slate-200 bg-white shadow-sm">
                          <div className="flex items-center justify-between space-x-2 mb-1">
                            <div className="font-bold text-slate-900">{new Date(consult.timestamp).toLocaleDateString()}</div>
                            <time className="font-caveat font-medium text-primary">{consult.status.toUpperCase()}</time>
                          </div>
                          <div className="text-slate-500">
                             <div className="text-sm font-semibold mb-2 text-primary">AI Rec: {consult.aiRecommendation}</div>
                             <div className="text-sm mb-2">Symptoms: {consult.symptoms.join(", ")}</div>
                             {consult.messages.length > 0 && (
                               <div className="mt-2 text-xs bg-muted p-2 rounded">
                                 Latest: "{consult.messages[consult.messages.length - 1].text}"
                               </div>
                             )}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
               </div>
             </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

// Icon helper
function Stethoscope(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M4.8 2.3A.3.3 0 1 0 5 2H4a2 2 0 0 0-2 2v5a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6V4a2 2 0 0 0-2-2h-1a.2.2 0 1 0 .3.3" />
      <path d="M8 15v1a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6v-4" />
      <circle cx="20" cy="10" r="2" />
    </svg>
  )
}
