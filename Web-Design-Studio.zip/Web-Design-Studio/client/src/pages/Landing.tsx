import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-telemedicine.png";
import { Activity, ShieldCheck, Zap, Globe, HeartPulse, UserCheck } from "lucide-react";

export default function Landing() {
  const [_, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background font-sans">
      {/* Navigation */}
      <nav className="border-b bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
              <Activity className="h-5 w-5 text-white" />
            </div>
            <span className="font-heading font-bold text-xl text-primary">VitalSix</span>
          </div>
          <div className="flex gap-4">
            <Button variant="ghost" onClick={() => setLocation("/auth")}>Login</Button>
            <Button onClick={() => setLocation("/auth")}>Get Started</Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-16 pb-32">
        <div className="absolute inset-0 z-0 opacity-10 bg-[radial-gradient(#0d9488_1px,transparent_1px)] [background-size:16px_16px]"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent text-accent-foreground text-sm font-medium">
                <ShieldCheck className="h-4 w-4" />
                Trusted by 500+ Rural Health Centers
              </div>
              <h1 className="font-heading text-5xl md:text-6xl font-bold leading-tight text-foreground">
                AI-Powered Healthcare for <span className="text-primary">Rural India</span>
              </h1>
              <p className="text-xl text-muted-foreground leading-relaxed">
                Empowering ASHA workers with AI diagnostics and instant specialist tele-consultations. Bridging the gap between rural patients and urban doctors.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="h-14 px-8 text-lg" onClick={() => setLocation("/auth")}>
                  Start Consultation
                </Button>
                <Button size="lg" variant="outline" className="h-14 px-8 text-lg">
                  Watch Demo
                </Button>
              </div>
              
              <div className="pt-8 grid grid-cols-3 gap-8 border-t">
                <div>
                  <div className="font-bold text-3xl text-primary">10k+</div>
                  <div className="text-sm text-muted-foreground">Patients Served</div>
                </div>
                <div>
                  <div className="font-bold text-3xl text-primary">500+</div>
                  <div className="text-sm text-muted-foreground">Active Doctors</div>
                </div>
                <div>
                  <div className="font-bold text-3xl text-primary">24/7</div>
                  <div className="text-sm text-muted-foreground">AI Support</div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="absolute -inset-4 bg-primary/20 rounded-3xl blur-3xl opacity-30 animate-pulse"></div>
              <img 
                src={heroImage} 
                alt="ASHA Worker" 
                className="relative rounded-2xl shadow-2xl border-4 border-white object-cover aspect-[4/3] w-full"
              />
              
              {/* Floating Card */}
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-xl border border-border max-w-[200px] animate-bounce duration-[3000ms]">
                <div className="flex items-center gap-3 mb-2">
                  <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                    <HeartPulse className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground">Diagnosis</div>
                    <div className="font-bold text-sm">Symptoms Analyzed</div>
                  </div>
                </div>
                <div className="h-1 w-full bg-secondary rounded-full overflow-hidden">
                  <div className="h-full w-[92%] bg-green-500 rounded-full"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24 bg-secondary/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="font-heading text-3xl font-bold mb-4">Why Choose VitalSix?</h2>
            <p className="text-muted-foreground">Designed specifically for low-connectivity environments and intuitive usage by ASHA workers.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Zap,
                title: "Instant AI Triage",
                desc: "Smart algorithms analyze symptoms instantly to recommend the right specialist."
              },
              {
                icon: Globe,
                title: "Works Offline",
                desc: "Record patient data without internet. Syncs automatically when connectivity is restored."
              },
              {
                icon: UserCheck,
                title: "Specialist Access",
                desc: "Direct line to gynecologists, pediatricians, and general physicians."
              }
            ].map((feature, i) => (
              <div key={i} className="bg-card p-8 rounded-xl border hover:shadow-lg transition-all hover:-translate-y-1">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-6">
                  <feature.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-heading text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
