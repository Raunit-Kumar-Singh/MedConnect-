import { useStore } from "@/lib/store";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Activity, UserCircle2, Stethoscope } from "lucide-react";
import doctorImg from "@/assets/doctor-avatar.png";
import ashaImg from "@/assets/asha-avatar.png";

export default function Auth() {
  const [_, setLocation] = useLocation();
  const setUserRole = useStore(state => state.setUserRole);

  const handleLogin = (role: 'asha' | 'doctor') => {
    setUserRole(role);
    setLocation(role === 'asha' ? '/dashboard/asha' : '/dashboard/doctor');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-secondary/30 p-4">
      <div className="w-full max-w-4xl grid md:grid-cols-2 gap-8 items-center">
        
        <div className="space-y-6">
          <div className="flex items-center gap-2 mb-8">
            <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
              <Activity className="h-6 w-6 text-white" />
            </div>
            <span className="font-heading font-bold text-2xl text-primary">VitalSix</span>
          </div>
          <h1 className="font-heading text-4xl font-bold text-foreground">Welcome Back</h1>
          <p className="text-muted-foreground text-lg">Sign in to access the telemedicine platform and manage patient records.</p>
        </div>

        <Card className="border-0 shadow-2xl">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold text-center">Login</CardTitle>
            <CardDescription className="text-center">Choose your role to continue</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="asha" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-8">
                <TabsTrigger value="asha">ASHA Worker</TabsTrigger>
                <TabsTrigger value="doctor">Doctor</TabsTrigger>
              </TabsList>
              
              <TabsContent value="asha">
                <div className="flex flex-col items-center mb-6">
                  <div className="h-24 w-24 rounded-full overflow-hidden border-4 border-white shadow-lg mb-4 bg-muted">
                    <img src={ashaImg} alt="ASHA" className="w-full h-full object-cover" />
                  </div>
                  <h3 className="font-bold text-lg">Health Worker Portal</h3>
                  <p className="text-sm text-muted-foreground text-center px-8">Access patient records, triage tools, and specialist requests.</p>
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email-asha">Worker ID</Label>
                    <Input id="email-asha" placeholder="ASHA-1029" defaultValue="ASHA-1029" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password-asha">Password</Label>
                    <Input id="password-asha" type="password" placeholder="••••••••" defaultValue="password" />
                  </div>
                  <Button className="w-full" size="lg" onClick={() => handleLogin('asha')}>
                    Login as ASHA
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="doctor">
                <div className="flex flex-col items-center mb-6">
                  <div className="h-24 w-24 rounded-full overflow-hidden border-4 border-white shadow-lg mb-4 bg-muted">
                    <img src={doctorImg} alt="Doctor" className="w-full h-full object-cover" />
                  </div>
                  <h3 className="font-bold text-lg">Specialist Portal</h3>
                  <p className="text-sm text-muted-foreground text-center px-8">Review consultation requests and provide remote diagnosis.</p>
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email-doc">Medical License ID</Label>
                    <Input id="email-doc" placeholder="MD-8821" defaultValue="MD-8821" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password-doc">Password</Label>
                    <Input id="password-doc" type="password" placeholder="••••••••" defaultValue="password" />
                  </div>
                  <Button className="w-full" size="lg" onClick={() => handleLogin('doctor')}>
                    Login as Doctor
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
