import { useState } from "react";
import { useStore, Patient } from "@/lib/store";
import { useLocation } from "wouter";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  User, 
  Eye, 
  Thermometer, 
  AlertCircle,
  Activity,
  Calendar
} from "lucide-react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogTrigger 
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

export default function MyPatients() {
  const { patients, requestConsultation } = useStore();
  const [searchTerm, setSearchTerm] = useState("");
  const [_, setLocation] = useLocation();
  const { toast } = useToast();

  // Consultation Dialog State
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [consultSymptoms, setConsultSymptoms] = useState("");
  const [isConsultOpen, setIsConsultOpen] = useState(false);

  const filteredPatients = patients.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleRequestConsultation = () => {
    if (selectedPatient) {
      requestConsultation(selectedPatient.id, consultSymptoms.split(",").map(s => s.trim()));
      setIsConsultOpen(false);
      setSelectedPatient(null);
      setConsultSymptoms("");
      toast({ 
        title: "Consultation Requested", 
        description: "Specialist has been notified." 
      });
    }
  };

  const getRiskColor = (status: Patient['status']) => {
    switch (status) {
      case 'Critical': return 'destructive';
      case 'Under Observation': return 'secondary';
      default: return 'outline';
    }
  };

  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col gap-2">
        <h1 className="text-4xl font-heading font-bold text-foreground">My Patients</h1>
        <p className="text-muted-foreground text-lg">Manage and monitor health records for your assigned village area.</p>
      </div>

      {/* Search Bar */}
      <div className="relative max-w-2xl">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input 
          placeholder="Search by patient name..." 
          className="pl-12 h-14 text-lg rounded-2xl border-2 focus:border-primary shadow-sm"
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Patient Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPatients.map((patient) => (
          <Card key={patient.id} className="group hover:shadow-xl transition-all duration-300 border-2 hover:border-primary/20 overflow-hidden rounded-3xl">
            <CardHeader className="pb-4">
              <div className="flex justify-between items-start mb-4">
                <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center text-primary text-2xl font-bold border-2 border-primary/5">
                  {patient.name.charAt(0)}
                </div>
                <Badge variant={getRiskColor(patient.status)} className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                  {patient.status === 'Under Observation' ? 'Moderate' : patient.status}
                </Badge>
              </div>
              <CardTitle className="text-2xl font-heading leading-tight group-hover:text-primary transition-colors">
                {patient.name}
              </CardTitle>
              <CardDescription className="flex items-center gap-2 text-sm mt-1">
                <User className="h-3.5 w-3.5" />
                {patient.age}y • {patient.gender}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-secondary/50 rounded-2xl border border-border/50">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  <span className="text-xs font-medium uppercase tracking-tight">Last Visit</span>
                </div>
                <span className="font-bold text-sm">{patient.lastVisit}</span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <Button 
                  variant="outline" 
                  className="h-12 rounded-xl border-2 hover:bg-primary/5 hover:border-primary/20 hover:text-primary font-bold"
                  onClick={() => setLocation(`/patients/${patient.id}`)}
                >
                  <Eye className="mr-2 h-4 w-4" /> Details
                </Button>
                
                <Dialog 
                  open={isConsultOpen && selectedPatient?.id === patient.id} 
                  onOpenChange={(open) => {
                    setIsConsultOpen(open);
                    if (open) setSelectedPatient(patient);
                  }}
                >
                  <DialogTrigger asChild>
                    <Button 
                      className="h-12 rounded-xl bg-primary shadow-lg shadow-primary/20 font-bold"
                      onClick={() => setLocation(`/consult/${patient.id}`)}
                    >
                      <Thermometer className="mr-2 h-4 w-4" /> Consult
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-xl rounded-3xl">
                    <DialogHeader>
                      <DialogTitle className="text-2xl font-heading">New Consultation</DialogTitle>
                      <DialogDescription>
                        AI analysis will determine urgency and recommended specialist.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-6 py-6">
                      <div className="p-4 bg-muted/50 rounded-2xl border flex items-center gap-4">
                        <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary font-bold">
                          {patient.name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-bold text-lg">{patient.name}</div>
                          <div className="text-sm text-muted-foreground">{patient.age}y • {patient.gender}</div>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <Label className="text-base font-bold flex items-center gap-2">
                          <Activity className="h-4 w-4 text-primary" />
                          Current Symptoms
                        </Label>
                        <Textarea 
                          placeholder="Describe patient symptoms in detail (e.g. fever for 2 days, persistent cough)..." 
                          className="min-h-[120px] rounded-2xl border-2 focus:border-primary text-base p-4"
                          value={consultSymptoms}
                          onChange={e => setConsultSymptoms(e.target.value)}
                        />
                        <p className="text-xs text-muted-foreground italic">
                          AI will process these symptoms to triage the case.
                        </p>
                      </div>

                      {consultSymptoms.length > 5 && (
                        <div className="p-5 bg-primary/5 rounded-2xl border-2 border-primary/10 animate-in zoom-in-95 duration-300">
                          <div className="flex items-center gap-2 mb-3 text-primary font-bold text-sm uppercase tracking-wider">
                            <AlertCircle className="h-4 w-4" />
                            AI Prediction
                          </div>
                          <div className="space-y-3">
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-muted-foreground">Specialist</span>
                              <Badge className="bg-primary hover:bg-primary px-3 py-1">
                                {consultSymptoms.toLowerCase().includes('pregnant') ? 'Gynecologist' : 'General Physician'}
                              </Badge>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-muted-foreground">Urgency</span>
                              <Badge variant="outline" className="border-primary text-primary px-3 py-1">Moderate</Badge>
                            </div>
                          </div>
                        </div>
                      )}

                      <Button 
                        className="w-full h-14 rounded-2xl text-lg font-bold shadow-xl shadow-primary/20"
                        onClick={handleRequestConsultation}
                        disabled={!consultSymptoms.trim()}
                      >
                        Send Consultation Request
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {filteredPatients.length === 0 && (
        <div className="text-center py-24 bg-card rounded-3xl border-2 border-dashed border-muted-foreground/20">
          <div className="h-20 w-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-6">
            <Search className="h-10 w-10 text-muted-foreground/40" />
          </div>
          <h3 className="text-2xl font-bold mb-2">No patients found</h3>
          <p className="text-muted-foreground">Try adjusting your search term or register a new patient.</p>
        </div>
      )}
    </div>
  );
}
