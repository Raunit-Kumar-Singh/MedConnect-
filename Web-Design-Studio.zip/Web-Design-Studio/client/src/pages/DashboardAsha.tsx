import { useState } from "react";
import { useStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Search, Thermometer, User, Clock, AlertCircle, Video, Eye } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export default function DashboardAsha() {
  const { patients, consultations, addPatient, requestConsultation } = useStore();
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();
  const [_, setLocation] = useLocation();
  
  // New Patient Form State
  const [newPatient, setNewPatient] = useState({ name: "", age: "", gender: "Male", symptoms: "", history: "" });
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // New Consultation State
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(null);
  const [consultSymptoms, setConsultSymptoms] = useState("");
  const [isConsultOpen, setIsConsultOpen] = useState(false);

  const filteredPatients = patients.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddPatient = () => {
    addPatient({
      name: newPatient.name,
      age: parseInt(newPatient.age),
      gender: newPatient.gender as any,
      symptoms: newPatient.symptoms.split(",").map(s => s.trim()),
      history: newPatient.history,
      lastVisit: new Date().toISOString().split('T')[0],
      status: "Stable"
    });
    setIsDialogOpen(false);
    toast({ title: "Success", description: "Patient record created successfully." });
    setNewPatient({ name: "", age: "", gender: "Male", symptoms: "", history: "" });
  };

  const handleRequestConsultation = () => {
    if (selectedPatientId) {
      requestConsultation(selectedPatientId, consultSymptoms.split(",").map(s => s.trim()));
      setIsConsultOpen(false);
      toast({ title: "Request Sent", description: "Consultation request sent to specialist." });
      setConsultSymptoms("");
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">My Dashboard</h1>
          <p className="text-muted-foreground">Welcome back, ASHA-1029</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="lg" className="shadow-lg shadow-primary/20">
              <Plus className="mr-2 h-5 w-5" /> Register New Patient
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Register New Patient</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Full Name</Label>
                  <Input value={newPatient.name} onChange={e => setNewPatient({...newPatient, name: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Age</Label>
                  <Input type="number" value={newPatient.age} onChange={e => setNewPatient({...newPatient, age: e.target.value})} />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Gender</Label>
                <select 
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
                  value={newPatient.gender}
                  onChange={e => setNewPatient({...newPatient, gender: e.target.value})}
                >
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label>Current Symptoms (comma separated)</Label>
                <Textarea value={newPatient.symptoms} onChange={e => setNewPatient({...newPatient, symptoms: e.target.value})} placeholder="e.g. Fever, Cough, Headache" />
              </div>
              <Button className="w-full" onClick={handleAddPatient}>Register Patient</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-2">
              <User className="h-4 w-4" /> Patients
            </div>
            <div className="text-3xl font-bold">{patients.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-2 text-muted-foreground mb-2">
              <Video className="h-4 w-4" /> Consultations
            </div>
            <div className="text-3xl font-bold">{consultations.length}</div>
          </CardContent>
        </Card>
        <Card className="bg-red-50 dark:bg-red-900/10 border-red-100 dark:border-red-900/20">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 text-red-600 mb-2">
              <AlertCircle className="h-4 w-4" /> Critical
            </div>
            <div className="text-3xl font-bold text-red-700">1</div>
          </CardContent>
        </Card>
      </div>

      {/* Patient List */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Recent Patients</CardTitle>
            <div className="relative w-64">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search patients..." 
                className="pl-8" 
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredPatients.map((patient) => (
              <div key={patient.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border rounded-xl hover:bg-secondary/50 transition-colors gap-4">
                <div className="flex items-center gap-4 cursor-pointer" onClick={() => setLocation(`/patients/${patient.id}`)}>
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                    {patient.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-bold text-foreground">{patient.name}</div>
                    <div className="text-sm text-muted-foreground flex items-center gap-2">
                      <span>{patient.age} years</span>
                      <span>•</span>
                      <span>{patient.gender}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-4 justify-end">
                  <div className="hidden md:block text-right">
                    <div className="text-xs text-muted-foreground">Last Visit</div>
                    <div className="text-sm font-medium">{patient.lastVisit}</div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button variant="ghost" size="sm" onClick={() => setLocation(`/patients/${patient.id}`)}>
                      <Eye className="mr-2 h-4 w-4" /> Details
                    </Button>
                    <Dialog open={isConsultOpen && selectedPatientId === patient.id} onOpenChange={(open) => {
                      setIsConsultOpen(open);
                      if (!open) setSelectedPatientId(null);
                    }}>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" onClick={() => setLocation(`/consult/${patient.id}`)}>
                          <Thermometer className="mr-2 h-4 w-4" /> Consult
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Request Specialist Consultation</DialogTitle>
                          <CardDescription>
                            AI will analyze symptoms to recommend the correct specialist.
                          </CardDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="p-4 bg-muted rounded-lg text-sm">
                            <span className="font-semibold">Patient:</span> {patient.name}, {patient.age}y
                          </div>
                          <div className="space-y-2">
                            <Label>Current Symptoms</Label>
                            <Textarea 
                              placeholder="Describe symptoms for AI analysis..." 
                              value={consultSymptoms}
                              onChange={e => setConsultSymptoms(e.target.value)}
                              className="h-32"
                            />
                          </div>
                          <Button className="w-full" onClick={handleRequestConsultation}>
                            Analyze & Request
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
