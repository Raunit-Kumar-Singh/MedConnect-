import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/Landing";
import Auth from "@/pages/Auth";
import DashboardLayout from "@/components/DashboardLayout";
import DashboardAsha from "@/pages/DashboardAsha";
import DashboardDoctor from "@/pages/DashboardDoctor";
import PatientDetails from "@/pages/PatientDetails";
import MyPatients from "@/pages/MyPatients";
import ConsultationPage from "@/pages/ConsultationPage";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/auth" component={Auth} />
      
      {/* Protected Routes Wrapper */}
      <Route path="/dashboard/asha">
        <DashboardLayout>
          <DashboardAsha />
        </DashboardLayout>
      </Route>
      <Route path="/dashboard/asha/patients">
        <DashboardLayout>
          <MyPatients />
        </DashboardLayout>
      </Route>
      <Route path="/consult/:patientId">
        <DashboardLayout>
          <ConsultationPage />
        </DashboardLayout>
      </Route>
      <Route path="/dashboard/doctor">
        <DashboardLayout>
          <DashboardDoctor />
        </DashboardLayout>
      </Route>
      
      <Route path="/patients/:id">
        <DashboardLayout>
          <PatientDetails />
        </DashboardLayout>
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
